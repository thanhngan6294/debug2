#include "edittablewidget.h"

editTableWidget::editTableWidget(QWidget * parent):
    QTableView(parent)
{
//    removeRow();
}
